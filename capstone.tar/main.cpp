#include "snake.cpp"
#include <iostream>
using namespace std;

int main(){
    int player1=0;
    int player2 = 0;
    Board board;
    board.print();
    int move;
    int boardsize = board.boardsize*board.boardsize;
    while (player1 < boardsize && player2 < boardsize){
        //Move player 
        cout << "Player 1's turn Press enter to roll the dice"<< endl;
        cin.ignore();
        move = board.dice();
        cout << "Player 1 rolled a " << move << "!" << endl;
        player1 +=move;
        switch (player1) {
            //check if the player hit a ladder
            case 8:
                player1 = 23;
                break;
            case 3:
                player1 = 17;
                break;
            case 16:
                player1= 21;
                break;
            //checks if the player hit a snake
            case 22:
                player1 = 0;
                break;
            case 15:
                player1 = 5;
                break;
            case 13:
                player1 = 2;
                break;
        }
        cout <<"Player 1 is at " << player1 << endl; 
        if(player1>= 25){ 
            cout << "Player1 wins!" <<endl;
            return 0;
        }   
        //Move player 2
        cout << "Player 2's turn Press enter to roll the dice"<< endl;
        cin.ignore();
        move = board.dice();
        cout << "Player 2 rolled a " << move << "!" << endl;
        player2 +=move;
        switch (player2) {
            //check if the player hit a ladder
            case 8:
                player2 = 23;
            case 3:
                player2 = 17;
            case 16:
                player2= 21;
            //checks if the player hit a snake
            case 22:
                player2 = 0;
            case 15:
                player2 = 5;
            case 13:
                player2 = 2;

        }
        cout <<"Player 2 is at " << player2 << endl; 


    }
       if (player2 >= 25){
        cout << "Player 2 wins";
        return 0;
    }
    }
