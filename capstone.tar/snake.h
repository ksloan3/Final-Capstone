// The header file 
//
//
//
using namespace std;
#include <string>
#include <vector>
class Board{
private:
vector<string> board;
public: 
int boardsize = 5;
Board();
int dice();
void print();
};
