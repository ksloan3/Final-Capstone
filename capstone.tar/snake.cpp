#include "snake.h"
#include "iostream"
#include <cstddef>
#include <cstdlib>

Board::Board(){
	board.resize(boardsize*boardsize);
	for(size_t i = 0; i < boardsize*boardsize; i++){
		board[i] = "__";
	}

	// Placing Snakes
	board[0] = "S1";
	board[22] = "S1";
	board[5] = "S2";
	board[15] = "S2";
	board[2] = "S3";
	board[13] = "S3";
	// Placing Ladders
	board[8] = "L1";
	board[23] = "L1";
	board[3] = "L2";
	board[17] = "L2";
	board[16] = "L3";
	board[21] = "L3";
}
int Board::dice(){

	srand(time(0));
	int roll = rand()%6 + 1;

	return roll;

}
void Board::print(){
	for(size_t i = 0; i < boardsize*boardsize; i++){

	cout <<"|" << board[i] << "|";

		if ((i+1)%boardsize ==0 && i !=0) cout << endl;
	}
}

